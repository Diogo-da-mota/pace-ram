import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface CorridaPublica {
  id: string;
  titulo: string;
  data_evento: string;
  local: string;
  imagem_principal?: string;
  link_externo?: string;
  texto_rodape?: string;
  descricao?: string;
}

export const useCorridasSeparadas = () => {
  const [corridasRecentes, setCorridasRecentes] = useState<CorridaPublica[]>([]);
  const [corridasEmBreve, setCorridasEmBreve] = useState<CorridaPublica[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const buscarCorridasSeparadas = useCallback(async (isRealTimeUpdate = false) => {
    try {
      if (!isRealTimeUpdate) {
        setLoading(true);
      }
      setError(null);
      
      // Melhorar a lógica de comparação de datas
      const agora = new Date();
      const hoje = agora.toISOString().split('T')[0]; // YYYY-MM-DD
      
      console.log(`[useCorridasSeparadas] Buscando corridas e eventos - Data de referência: ${hoje}`, {
        isRealTimeUpdate,
        timestamp: agora.toISOString()
      });
      
      // Buscar corridas recentes (data <= hoje)
      const { data: corridasRecentes, error: errorCorridasRecentes } = await supabase
        .from('corridas')
        .select('*')
        .eq('publicado', true)
        .lte('data_evento', hoje);

      // Buscar corridas em breve (data > hoje)
      const { data: corridasEmBreve, error: errorCorridasEmBreve } = await supabase
        .from('corridas')
        .select('*')
        .eq('publicado', true)
        .gt('data_evento', hoje);

      // Buscar eventos recentes (data <= hoje)
      const { data: eventosRecentes, error: errorEventosRecentes } = await supabase
        .from('eventos_calendario')
        .select('*')
        .eq('publicado', true)
        .lte('data_evento', hoje);

      // Buscar eventos em breve (data > hoje)
      const { data: eventosEmBreve, error: errorEventosEmBreve } = await supabase
        .from('eventos_calendario')
        .select('*')
        .eq('publicado', true)
        .gt('data_evento', hoje);

      if (errorCorridasRecentes) throw errorCorridasRecentes;
      if (errorCorridasEmBreve) throw errorCorridasEmBreve;
      if (errorEventosRecentes) throw errorEventosRecentes;
      if (errorEventosEmBreve) throw errorEventosEmBreve;

      // Combinar corridas e eventos, convertendo eventos para o formato de corridas
      const eventosRecentesFormatados = (eventosRecentes || []).map(evento => ({
        ...evento,
        imagem_principal: evento.imagem_principal || null,
        texto_rodape: evento.texto_rodape || 'Evento do calendário',
        descricao: evento.descricao || null
      }));

      const eventosEmBreveFormatados = (eventosEmBreve || []).map(evento => ({
        ...evento,
        imagem_principal: evento.imagem_principal || null,
        texto_rodape: evento.texto_rodape || 'Inscrições abertas',
        descricao: evento.descricao || null
      }));

      // Combinar e ordenar
      const recentesCombinados = [...(corridasRecentes || []), ...eventosRecentesFormatados]
        .sort((a, b) => new Date(b.data_evento).getTime() - new Date(a.data_evento).getTime());

      const emBreveCombinados = [...(corridasEmBreve || []), ...eventosEmBreveFormatados]
        .sort((a, b) => new Date(a.data_evento).getTime() - new Date(b.data_evento).getTime());



      console.log(`[useCorridasSeparadas] Resultados combinados:`, {
        recentesCount: recentesCombinados.length,
        emBreveCount: emBreveCombinados.length,
        corridasRecentesCount: corridasRecentes?.length || 0,
        eventosRecentesCount: eventosRecentes?.length || 0,
        corridasEmBreveCount: corridasEmBreve?.length || 0,
        eventosEmBreveCount: eventosEmBreve?.length || 0,
        recentes: recentesCombinados.map(c => ({ id: c.id, titulo: c.titulo, data_evento: c.data_evento, tipo: c.categoria_id ? 'corrida' : 'evento' })),
        emBreve: emBreveCombinados.map(c => ({ id: c.id, titulo: c.titulo, data_evento: c.data_evento, tipo: c.categoria_id ? 'corrida' : 'evento' }))
      });

      setCorridasRecentes(recentesCombinados);
      setCorridasEmBreve(emBreveCombinados);
    } catch (error: any) {
      console.error('Erro ao buscar corridas separadas:', error);
      setError(error.message);
    } finally {
      if (!isRealTimeUpdate) {
        setLoading(false);
      }
    }
  }, []);

  // Função para refetch com delay (para mudanças em tempo real)
  const refetchWithDelay = useCallback((payload?: any) => {
    console.log('[useCorridasSeparadas] Mudança detectada no banco:', payload);
    
    // Limpar timeout anterior se existir
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    // Adicionar delay de 500ms antes de refazer a busca
    timeoutRef.current = setTimeout(() => {
      console.log('[useCorridasSeparadas] Executando refetch após delay');
      buscarCorridasSeparadas(true);
    }, 500);
  }, [buscarCorridasSeparadas]);

  // Função de refetch manual (sem delay)
  const refetchManual = useCallback(() => {
    console.log('[useCorridasSeparadas] Refetch manual solicitado');
    buscarCorridasSeparadas(false);
  }, [buscarCorridasSeparadas]);

  useEffect(() => {
    // Busca inicial
    buscarCorridasSeparadas(false);
    
    // Configurar canal de real-time para ambas as tabelas
    const channel = supabase
      .channel('corridas-separadas-changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'corridas'
      }, (payload) => {
        console.log('[useCorridasSeparadas] Mudança detectada na tabela corridas:', payload);
        refetchWithDelay(payload);
      })
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'eventos_calendario'
      }, (payload) => {
        console.log('[useCorridasSeparadas] Mudança detectada na tabela eventos_calendario:', payload);
        refetchWithDelay(payload);
      })
      .subscribe();
    
    console.log('[useCorridasSeparadas] Canal de real-time configurado para corridas e eventos_calendario');
    
    return () => {
      console.log('[useCorridasSeparadas] Limpando recursos');
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      supabase.removeChannel(channel);
    };
  }, [refetchWithDelay]);

  return {
    corridasRecentes,
    corridasEmBreve,
    loading,
    error,
    refetch: refetchManual,
    refetchWithDelay
  };
};