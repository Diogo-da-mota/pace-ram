# 🛠️ TEMPLATES DE CÓDIGO - PERFORMANCE OTIMIZADA

## 📋 TEMPLATES PRONTOS PARA USO

Copie e cole estes templates em seus projetos para garantir performance desde o início.

---

## 🎣 HOOK TEMPLATE - DADOS PÚBLICOS

```typescript
// hooks/use[Feature]Public.ts
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface [Feature]Public {
  id: string;
  titulo: string;
  descricao?: string;
  ativo: boolean;
  created_at: string;
}

interface CachedData {
  data: [Feature]Public[];
  timestamp: number;
}

const CACHE_KEY = '[feature]-cache';
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutos

const getCachedData = (): [Feature]Public[] | null => {
  try {
    const cached = localStorage.getItem(CACHE_KEY);
    if (cached) {
      const data: CachedData = JSON.parse(cached);
      if (Date.now() - data.timestamp < CACHE_DURATION) {
        return data.data;
      }
    }
  } catch (error) {
    console.warn('Erro ao ler cache:', error);
  }
  return null;
};

const setCachedData = (data: [Feature]Public[]) => {
  try {
    const cacheData: CachedData = {
      data,
      timestamp: Date.now()
    };
    localStorage.setItem(CACHE_KEY, JSON.stringify(cacheData));
  } catch (error) {
    console.warn('Erro ao salvar cache:', error);
  }
};

export const use[Feature]Public = () => {
  const [data, setData] = useState<[Feature]Public[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async (forceRefresh = false) => {
    try {
      setLoading(true);
      setError(null);

      // Tentar usar cache primeiro
      if (!forceRefresh) {
        const cachedData = getCachedData();
        if (cachedData) {
          setData(cachedData);
          setLoading(false);
          return;
        }
      }

      const { data: result, error: fetchError } = await supabase
        .from('[table_name]')
        .select('*')
        .eq('ativo', true)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      setData(result || []);
      setCachedData(result || []);
    } catch (err) {
      console.error('Erro ao buscar [feature]:', err);
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    
    // Realtime subscription
    const channel = supabase
      .channel('[table_name]-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: '[table_name]'
        },
        (payload) => {
          console.log('Mudança detectada na tabela [table_name]:', payload);
          fetchData(true); // Force refresh
        }
      )
      .subscribe();
    
    // Cleanup obrigatório
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return {
    data,
    loading,
    error,
    refetch: () => fetchData(true)
  };
};
```

---

## 🎨 COMPONENTE TEMPLATE - OTIMIZADO

```typescript
// components/[Feature]Card.tsx
import React, { memo, useMemo, useCallback } from 'react';

interface [Feature]CardProps {
  item: {
    id: string;
    titulo: string;
    descricao?: string;
    created_at: string;
  };
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  showActions?: boolean;
}

const [Feature]Card = memo(({ 
  item, 
  onEdit, 
  onDelete, 
  showActions = true 
}: [Feature]CardProps) => {
  
  // Memoizar data formatada
  const formattedDate = useMemo(() => {
    return new Date(item.created_at).toLocaleDateString('pt-BR');
  }, [item.created_at]);

  // Memoizar handlers
  const handleEdit = useCallback(() => {
    onEdit?.(item.id);
  }, [onEdit, item.id]);

  const handleDelete = useCallback(() => {
    onDelete?.(item.id);
  }, [onDelete, item.id]);

  return (
    <div className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow duration-200">
      <h3 className="text-lg font-semibold text-gray-900 mb-2">
        {item.titulo}
      </h3>
      
      {item.descricao && (
        <p className="text-gray-600 mb-3 line-clamp-2">
          {item.descricao}
        </p>
      )}
      
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-500">
          {formattedDate}
        </span>
        
        {showActions && (
          <div className="flex gap-2">
            {onEdit && (
              <button
                onClick={handleEdit}
                className="px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
              >
                Editar
              </button>
            )}
            {onDelete && (
              <button
                onClick={handleDelete}
                className="px-3 py-1 text-sm bg-red-500 text-white rounded hover:bg-red-600 transition-colors"
              >
                Excluir
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
});

[Feature]Card.displayName = '[Feature]Card';

export default [Feature]Card;
```

---

## 📱 COMPONENTE BACKGROUND OTIMIZADO

```typescript
// components/OptimizedBackground.tsx
import React, { useState, useEffect, useMemo } from 'react';

interface BackgroundImageProps {
  desktopImage?: string;
  mobileImage?: string;
  className?: string;
  opacity?: number;
}

const OptimizedBackground = React.memo(({ 
  desktopImage, 
  mobileImage, 
  className = "",
  opacity = 0.8 
}: BackgroundImageProps) => {
  const [isMobile, setIsMobile] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  // Detectar dispositivo móvel com cleanup
  useEffect(() => {
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    checkIsMobile();
    window.addEventListener('resize', checkIsMobile);

    return () => window.removeEventListener('resize', checkIsMobile);
  }, []);

  // Selecionar imagem apropriada
  const currentImage = useMemo(() => {
    return isMobile ? mobileImage : desktopImage;
  }, [isMobile, mobileImage, desktopImage]);

  // Estilo otimizado com memoização
  const backgroundStyle = useMemo(() => {
    if (!currentImage) return {};
    
    return {
      backgroundImage: `url(${currentImage})`,
      backgroundPosition: 'center',
      backgroundSize: 'cover',
      backgroundRepeat: 'no-repeat',
      // Otimização crítica para mobile
      backgroundAttachment: isMobile ? 'scroll' : 'fixed',
      opacity: imageLoaded ? opacity : 0,
      transition: 'opacity 0.5s ease-in-out'
    };
  }, [currentImage, isMobile, opacity, imageLoaded]);

  // Handler de carregamento
  const handleImageLoad = () => {
    setImageLoaded(true);
  };

  if (!currentImage) return null;

  return (
    <>
      {/* Preload da imagem */}
      <img
        src={currentImage}
        alt=""
        style={{ display: 'none' }}
        onLoad={handleImageLoad}
        loading="lazy"
      />
      
      {/* Background div */}
      <div
        className={`fixed inset-0 w-full h-full ${className}`}
        style={backgroundStyle}
        aria-hidden="true"
      />
    </>
  );
});

OptimizedBackground.displayName = 'OptimizedBackground';

export default OptimizedBackground;
```

---

## 🔧 UTILITY TEMPLATE - CACHE

```typescript
// utils/cache.ts

interface CacheData<T> {
  data: T;
  timestamp: number;
}

export class CacheManager {
  private static instance: CacheManager;
  private defaultTTL = 5 * 60 * 1000; // 5 minutos

  static getInstance(): CacheManager {
    if (!CacheManager.instance) {
      CacheManager.instance = new CacheManager();
    }
    return CacheManager.instance;
  }

  set<T>(key: string, data: T, ttl?: number): void {
    try {
      const cacheData: CacheData<T> = {
        data,
        timestamp: Date.now()
      };
      localStorage.setItem(key, JSON.stringify(cacheData));
    } catch (error) {
      console.warn(`Erro ao salvar cache para ${key}:`, error);
    }
  }

  get<T>(key: string, ttl?: number): T | null {
    try {
      const cached = localStorage.getItem(key);
      if (!cached) return null;

      const cacheData: CacheData<T> = JSON.parse(cached);
      const maxAge = ttl || this.defaultTTL;

      if (Date.now() - cacheData.timestamp < maxAge) {
        return cacheData.data;
      }

      // Cache expirado, remover
      this.remove(key);
      return null;
    } catch (error) {
      console.warn(`Erro ao ler cache para ${key}:`, error);
      return null;
    }
  }

  remove(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.warn(`Erro ao remover cache para ${key}:`, error);
    }
  }

  clear(): void {
    try {
      localStorage.clear();
    } catch (error) {
      console.warn('Erro ao limpar cache:', error);
    }
  }

  isExpired(key: string, ttl?: number): boolean {
    try {
      const cached = localStorage.getItem(key);
      if (!cached) return true;

      const cacheData: CacheData<any> = JSON.parse(cached);
      const maxAge = ttl || this.defaultTTL;

      return Date.now() - cacheData.timestamp >= maxAge;
    } catch (error) {
      return true;
    }
  }
}

// Instância singleton
export const cache = CacheManager.getInstance();

// Hooks para usar o cache
export const useCache = <T>(key: string, ttl?: number) => {
  const get = (): T | null => cache.get<T>(key, ttl);
  const set = (data: T) => cache.set(key, data, ttl);
  const remove = () => cache.remove(key);
  const isExpired = () => cache.isExpired(key, ttl);

  return { get, set, remove, isExpired };
};
```

---

## 🛡️ ERROR BOUNDARY TEMPLATE

```typescript
// components/ErrorBoundary.tsx
import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary capturou um erro:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Oops! Algo deu errado
            </h2>
            <p className="text-gray-600 mb-6">
              Ocorreu um erro inesperado. Tente recarregar a página.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              Recarregar Página
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
```

---

## 🔄 REALTIME MANAGER TEMPLATE

```typescript
// utils/realtimeManager.ts
import { supabase } from '@/integrations/supabase/client';
import { RealtimeChannel } from '@supabase/supabase-js';

export class RealtimeManager {
  private static instance: RealtimeManager;
  private channels: Map<string, RealtimeChannel> = new Map();

  static getInstance(): RealtimeManager {
    if (!RealtimeManager.instance) {
      RealtimeManager.instance = new RealtimeManager();
    }
    return RealtimeManager.instance;
  }

  subscribe(
    channelName: string,
    table: string,
    callback: (payload: any) => void,
    event: '*' | 'INSERT' | 'UPDATE' | 'DELETE' = '*'
  ): RealtimeChannel {
    // Remover canal existente se houver
    this.unsubscribe(channelName);

    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event,
          schema: 'public',
          table
        },
        (payload) => {
          console.log(`Mudança detectada na tabela ${table}:`, payload);
          callback(payload);
        }
      )
      .subscribe();

    this.channels.set(channelName, channel);
    return channel;
  }

  unsubscribe(channelName: string): void {
    const channel = this.channels.get(channelName);
    if (channel) {
      supabase.removeChannel(channel);
      this.channels.delete(channelName);
    }
  }

  unsubscribeAll(): void {
    this.channels.forEach((channel, name) => {
      supabase.removeChannel(channel);
    });
    this.channels.clear();
  }

  getActiveChannels(): string[] {
    return Array.from(this.channels.keys());
  }
}

// Instância singleton
export const realtimeManager = RealtimeManager.getInstance();

// Hook para usar Realtime
export const useRealtime = (
  channelName: string,
  table: string,
  callback: (payload: any) => void,
  event: '*' | 'INSERT' | 'UPDATE' | 'DELETE' = '*'
) => {
  React.useEffect(() => {
    const channel = realtimeManager.subscribe(channelName, table, callback, event);

    return () => {
      realtimeManager.unsubscribe(channelName);
    };
  }, [channelName, table, callback, event]);
};
```

---

## 📋 CHECKLIST DE IMPLEMENTAÇÃO

### ✅ Antes de Começar:
- [ ] Copiar templates necessários
- [ ] Configurar Supabase
- [ ] Instalar dependências (React Query, etc.)
- [ ] Configurar TailwindCSS
- [ ] Configurar TypeScript

### ✅ Durante o Desenvolvimento:
- [ ] Usar hooks com cache
- [ ] Implementar Realtime
- [ ] Adicionar Error Boundaries
- [ ] Otimizar componentes com memo
- [ ] Implementar cleanup adequado

### ✅ Antes do Deploy:
- [ ] Testar cache funcionando
- [ ] Verificar Realtime funcionando
- [ ] Testar error handling
- [ ] Verificar console limpo
- [ ] Testar performance mobile

---

## 🎯 RESULTADO GARANTIDO

Usando estes templates, você terá:
- ⚡ **Performance otimizada** desde o início
- 🔄 **Realtime funcionando** perfeitamente
- 💾 **Cache inteligente** implementado
- 🛡️ **Error handling** robusto
- 🧹 **Código limpo** e organizado
- 📱 **Mobile otimizado** automaticamente

**Copie, cole e tenha sucesso garantido! 🚀**