# PRD - Páginas Principais do Pace Run Hub

## 1. Product Overview

O Pace Run Hub é uma plataforma digital dedicada à comunidade de corredores de Rio Verde e região, centralizando informações sobre corridas, eventos e recursos úteis para atletas. O produto oferece duas páginas principais que atendem diferentes necessidades dos usuários: a página inicial como hub central de informações e o calendário como ferramenta de descoberta e planejamento de eventos.

## 2. Core Features

### 2.1 User Roles

| Role              | Registration Method        | Core Permissions                                                              |
| ----------------- | -------------------------- | ----------------------------------------------------------------------------- |
| Visitante Público | Acesso direto sem registro | Visualizar todas as informações públicas, navegar entre páginas, usar filtros |
| Administrador     | Login via credenciais      | Gerenciar conteúdos, adicionar/editar corridas e eventos (acesso via /login)  |

### 2.2 Feature Module

Nosso sistema consiste nas seguintes páginas principais:

1. **Página Inicial (/)**: header de navegação, seção de redes sociais, corridas recentes, corridas em breve, links úteis e footer
2. **Página Calendário (/calendario)**: header de navegação, título principal, sistema de filtros avançados, lista de eventos e footer

### 2.3 Page Details

| Page Name                | Module Name             | Feature description                                                                                          |
| ------------------------ | ----------------------- | ------------------------------------------------------------------------------------------------------------ |
| Página Inicial (/)       | Header Fixo             | Exibe logo PACE RAM, navegação responsiva, botão dark/light mode, link para calendário e botão de login      |
| Página Inicial (/)       | Seção Redes Sociais     | Apresenta título diagonal "Redes Sociais", grid responsivo com cards do Instagram, WhatsApp e links externos |
| Página Inicial (/)       | Seção Corridas Recentes | Título diagonal "Corridas Recentes", grid de cards com fotos, títulos, datas, locais e links para fotos      |
| Página Inicial (/)       | Seção Em Breve          | Título diagonal "⏰ Em Breve", cards de corridas futuras com informações de inscrição                         |
| Página Inicial (/)       | Seção Links Úteis       | Título "Dúvidas e Links externos", cards com links para FAQ e acesso a fotos                                 |
| Página Inicial (/)       | Footer                  | Copyright e informações da marca PACE RAM                                                                    |
| Calendário (/calendario) | Header Fixo             | Idêntico à página inicial com navegação completa                                                             |
| Calendário (/calendario) | Título Principal        | "CALENDÁRIO DE CORRIDAS - RIO VERDE E REGIÃO - ANO DE 2025" em destaque                                      |
| Calendário (/calendario) | Sistema de Filtros      | 4 filtros: Ano, Região, Distância (3K a Maratona) e Status (Abertas/Andamento/Encerrado)                     |
| Calendário (/calendario) | Controle de Filtros     | Botão "Limpar Filtros" aparece quando há filtros ativos                                                      |
| Calendário (/calendario) | Lista de Eventos        | Cards detalhados com informações completas dos eventos, animações de entrada                                 |
| Calendário (/calendario) | Estados de Loading      | Spinner e mensagens durante carregamento de dados                                                            |
| Calendário (/calendario) | Footer                  | Idêntico à página inicial                                                                                    |

## 3. Core Process

### Fluxo do Visitante Público:

1. Usuário acessa a página inicial (/) e visualiza o header com logo PACE RAM
2. Navega pela seção de redes sociais com cards do Instagram, WhatsApp e links externos
3. Explora as corridas recentes com fotos e informações detalhadas
4. Verifica corridas em breve para futuras participações
5. Acessa links úteis para FAQ e download de fotos
6. Pode clicar no botão "Calendário" no header para acessar a página de eventos
7. Na página calendário, visualiza o título principal e sistema de filtros
8. Aplica filtros por ano, região, distância ou status conforme necessário
9. Navega pela lista de eventos filtrados
10. Pode limpar filtros ou retornar à página inicial

```mermaid
graph TD
    A[Página Inicial /] --> B[Seção Redes Sociais]
    A --> C[Corridas Recentes]
    A --> D[Corridas Em Breve]
    A --> E[Links Úteis]
    A --> F[Calendário /calendario]
    F --> G[Sistema de Filtros]
    G --> H[Lista de Eventos]
    H --> I[Detalhes do Evento]
    F --> A
```

## 4. User Interface Design

### 4.1 Design Style

* **Cores Primárias**: Preto (#000000) para headers e seções de destaque, azul (#3B82F6) para elementos interativos

* **Cores Secundárias**: Cinza escuro para backgrounds, branco para textos em contraste

* **Modo Escuro**: Suporte completo com toggle no header, cores adaptadas automaticamente

* **Botões**: Estilo arredondado com hover effects, sombras sutis e transições suaves

* **Tipografia**: Roboto como fonte principal, tamanhos responsivos (text-xl a text-4xl)

* **Layout**: Grid responsivo, espaçamentos consistentes, animações de entrada suaves

* **Ícones**: Lucide React para consistência, tamanhos 16px a 24px

### 4.2 Page Design Overview

| Page Name          | Module Name       | UI Elements                                                                                              |
| ------------------ | ----------------- | -------------------------------------------------------------------------------------------------------- |
| Página Inicial (/) | Header            | Background preto semi-transparente fixo, logo à esquerda, navegação responsiva, botões azuis com hover   |
| Página Inicial (/) | Redes Sociais     | Título diagonal em destaque, grid 2x2 mobile / 4 colunas desktop, cards com ícones coloridos             |
| Página Inicial (/) | Corridas Recentes | Background preto, título diagonal branco, grid responsivo 2-3-5 colunas, cards com imagens e hover scale |
| Página Inicial (/) | Em Breve          | Background claro, título com emoji, layout idêntico às corridas recentes                                 |
| Página Inicial (/) | Links Úteis       | Cards simples com links externos, espaçamento generoso                                                   |
| Calendário         | Título Principal  | Gradiente de fundo, texto centralizado em múltiplas linhas, tipografia bold                              |
| Calendário         | Filtros           | Grid 2x2 mobile / 4 colunas desktop, selects estilizados, botão limpar à direita                         |
| Calendário         | Eventos           | Cards em lista vertical, animações escalonadas, estados de loading e vazio                               |

### 4.3 Responsiveness

O produto é mobile-first com adaptação progressiva para desktop. Breakpoints principais em 768px (md) e 1024px (lg). Touch interactions otimizadas para mobile com áreas de toque adequadas. Grid systems flexíveis que se adaptam de 2 colunas (mobile) até 5 colunas (desktop) conforme o conteúdo.

## 5. Funcionalidades Técnicas Detalhadas

### 5.1 Sistema de Loading e Estados

* **Loading Inicial**: RunnerLoader com mensagens contextuais ("Preparando sua experiência...", "Carregando redes sociais...")

* **Estados Vazios**: Dados de fallback para demonstração quando não há conteúdo no banco

* **Error Handling**: Mensagens de erro amigáveis com opções de retry

### 5.2 Animações e Transições

* **Entrada de Elementos**: fade-in, slide-up, scale-in com delays escalonados

* **Hover Effects**: scale-105 em cards, mudanças de cor suaves

* **Transições**: duration-300 padrão, easing natural

### 5.3 Sistema de Filtros (Calendário)

* **Filtros Disponíveis**: Ano (dinâmico), Região (baseado em dados), Distância (predefinido), Status (3 opções)

* **Interação**: Aplicação automática ao selecionar, estado visual dos filtros ativos

* **Reset**: Botão "Limpar Filtros" aparece condicionalmente

### 5.4 Dados de Fallback

* **Corridas**: 3 exemplos com imagens, datas e locais realistas

* **Eventos**: Lista de eventos de exemplo para demonstração

* **Redes Sociais**: Instagram, WhatsApp e site oficial como padrão

* **Links Úteis**: FAQ e acesso a fotos como conteúdo base

### 5.5 Navegação e UX

* **Header Fixo**: Sempre visível durante scroll, background semi-transparente

* **Breadcrumb Visual**: Logo clicável sempre retorna à home

* **Estados Interativos**: Feedback visual em todos os elementos clicáveis

* **Acessibilidade**: Labels adequados, contraste suficiente, navegação por teclado

