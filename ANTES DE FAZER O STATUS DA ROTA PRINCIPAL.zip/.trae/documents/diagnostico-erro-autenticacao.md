# Relatório de Diagnóstico - Erro de Autenticação
## Sistema Pace Run Hub

**Data:** 11 de Janeiro de 2025  
**Usuário Afetado:** paceram@gmail.com  
**Erro Reportado:** "Usuário não autenticado" (mesmo após login bem-sucedido)

---

## 🔍 DIAGNÓSTICO

Após análise detalhada do código e estrutura do banco de dados, identifiquei **múltiplas inconsistências críticas** no sistema de autenticação que explicam o erro reportado:

### Problemas Identificados:

1. **Inconsistência de Esquema de Dados**: O prompt menciona tabela `public.perfis`, mas o sistema usa `public.usuarios`
2. **RLS Desabilitado**: Row Level Security foi temporariamente desabilitado na tabela usuarios
3. **Múltiplos Hooks de Autenticação**: Existem dois hooks conflitantes (`useAuth` e `useAuthSession`)
4. **Google OAuth Inexistente**: Sistema não implementa Google OAuth, apenas email/senha
5. **Políticas RLS Problemáticas**: Histórico de problemas de recursão infinita nas políticas

---

## 🎯 CAUSA RAIZ

**Problema Principal:** Desalinhamento entre a expectativa do sistema (Google OAuth + tabela perfis) e a implementação real (email/senha + tabela usuarios com RLS desabilitado).

### Evidências Técnicas:

#### 1. Estrutura do Banco de Dados
```sql
-- REAL: Tabela usuarios existe
CREATE TABLE usuarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    nome VARCHAR(100) NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    tipo_usuario VARCHAR(20) DEFAULT 'usuario',
    ativo BOOLEAN DEFAULT true,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ESPERADO NO PROMPT: Tabela perfis (NÃO EXISTE)
-- SELECT FROM public.perfis -- Esta query falhará
```

#### 2. Estado Atual do RLS
```sql
-- RLS foi desabilitado temporariamente
ALTER TABLE usuarios DISABLE ROW LEVEL SECURITY;
-- Comentário: 'RLS temporariamente desabilitado para permitir inserção de usuários'
```

#### 3. Configuração do Supabase Client
```typescript
// Cliente principal (localStorage)
export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: localStorage,
    persistSession: true,
    autoRefreshToken: true,
  }
});

// Cliente alternativo (sessionStorage) - CONFLITO POTENCIAL
export const supabaseSession = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: sessionStorage,
    persistSession: true,
    autoRefreshToken: true,
  }
});
```

#### 4. Hooks de Autenticação Conflitantes
- **useAuth.ts**: Usa `supabase` (localStorage)
- **useAuthSession.ts**: Usa `supabaseSession` (sessionStorage)

#### 5. Ausência de Google OAuth
```typescript
// IMPLEMENTADO: Apenas email/senha
const { data, error } = await supabase.auth.signInWithPassword({
  email,
  password,
});

// NÃO IMPLEMENTADO: Google OAuth
// const { data, error } = await supabase.auth.signInWithOAuth({
//   provider: 'google'
// });
```

---

## ✅ SOLUÇÃO

### Passo 1: Corrigir Queries de Diagnóstico
```sql
-- Query 1: Verificar se o usuário existe (CORRIGIDA)
SELECT 
    u.id, 
    u.email, 
    u.email_confirmed_at, 
    u.last_sign_in_at, 
    u.created_at 
FROM auth.users u 
WHERE u.email = 'paceram@gmail.com';

-- Query 2: Verificar identidades do usuário
SELECT 
    i.id, 
    i.user_id, 
    i.provider, 
    i.provider_id, 
    i.created_at, 
    i.last_sign_in_at 
FROM auth.identities i 
JOIN auth.users u ON i.user_id = u.id 
WHERE u.email = 'paceram@gmail.com';

-- Query 3: Verificar perfil na tabela CORRETA (usuarios, não perfis)
SELECT 
    u.id, 
    u.nome, 
    u.email, 
    u.tipo_usuario as role, 
    u.criado_em as created_at 
FROM public.usuarios u 
JOIN auth.users au ON u.id = au.id 
WHERE au.email = 'paceram@gmail.com';

-- Query 4: Verificar sessões ativas
SELECT 
    s.id, 
    s.user_id, 
    s.created_at, 
    s.updated_at, 
    s.not_after, 
    (s.not_after > NOW()) as is_active 
FROM auth.sessions s 
JOIN auth.users u ON s.user_id = u.id 
WHERE u.email = 'paceram@gmail.com' 
ORDER BY s.created_at DESC 
LIMIT 5;

-- Query 5: Verificar políticas RLS da tabela CORRETA (usuarios, não perfis)
SELECT 
    policyname, 
    cmd, 
    qual, 
    with_check 
FROM pg_policies 
WHERE schemaname = 'public' 
AND tablename = 'usuarios';

-- Query 6: Testar auth.uid() quando logado
SELECT 
    auth.uid() as current_user_id, 
    auth.role() as current_role, 
    (auth.uid() IS NOT NULL) as has_auth_context;
```

### Passo 2: Reabilitar e Corrigir RLS
```sql
-- Reabilitar RLS na tabela usuarios
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;

-- Remover políticas antigas problemáticas
DROP POLICY IF EXISTS "usuarios_select_own" ON usuarios;
DROP POLICY IF EXISTS "usuarios_insert_own" ON usuarios;
DROP POLICY IF EXISTS "usuarios_update_own" ON usuarios;

-- Criar políticas simples e funcionais
CREATE POLICY "usuarios_select_policy" ON usuarios
    FOR SELECT
    USING (
        auth.uid() = id OR 
        auth.role() = 'authenticated'
    );

CREATE POLICY "usuarios_insert_policy" ON usuarios
    FOR INSERT
    WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "usuarios_update_policy" ON usuarios
    FOR UPDATE
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- Garantir permissões básicas
GRANT SELECT, INSERT, UPDATE ON usuarios TO authenticated;
GRANT SELECT ON usuarios TO anon;
```

### Passo 3: Implementar Google OAuth (se necessário)
```typescript
// Adicionar ao useAuth.ts
const signInWithGoogle = async () => {
  try {
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/dashboard`
      }
    });

    if (error) {
      console.error('Erro no login com Google:', error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (error) {
    console.error('Erro no login com Google:', error);
    return { success: false, error: 'Erro interno do sistema' };
  } finally {
    setLoading(false);
  }
};
```

### Passo 4: Criar Trigger para Sincronização de Usuários
```sql
-- Função para criar usuário na tabela usuarios quando auth.users é criado
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.usuarios (id, email, nome, tipo_usuario)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    'usuario'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para executar a função
CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
```

### Passo 5: Unificar Hooks de Autenticação
```typescript
// Remover useAuthSession.ts e usar apenas useAuth.ts
// Ou consolidar ambos em um único hook

// Configuração unificada do cliente
export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: localStorage, // Usar apenas localStorage
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true // Para OAuth
  }
});
```

### Passo 6: Validação Completa
```typescript
// Adicionar logs de debug no useAuth
useEffect(() => {
  const getSession = async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      
      console.log('Session check:', {
        session: session,
        user: session?.user,
        error: error
      });
      
      if (error) {
        console.error('Erro ao obter sessão:', error);
      } else {
        setSession(session);
        setUser(session?.user ?? null);
        
        // Verificar se usuário existe na tabela usuarios
        if (session?.user) {
          const { data: userData, error: userError } = await supabase
            .from('usuarios')
            .select('*')
            .eq('id', session.user.id)
            .single();
            
          console.log('User data check:', {
            userData: userData,
            userError: userError
          });
        }
      }
    } catch (error) {
      console.error('Erro ao verificar sessão:', error);
    } finally {
      setLoading(false);
    }
  };

  getSession();
}, []);
```

---

## ⚠️ PREVENÇÃO

### Como evitar este problema no futuro:

1. **Documentação Clara**: Manter documentação atualizada sobre estrutura do banco
2. **Testes de Integração**: Implementar testes automatizados para autenticação
3. **Monitoramento**: Adicionar logs detalhados para rastrear problemas de auth
4. **Versionamento de Schema**: Usar migrações versionadas para mudanças no banco
5. **Hook Único**: Manter apenas um hook de autenticação para evitar conflitos
6. **Validação de Ambiente**: Verificar consistência entre desenvolvimento e produção

### Checklist de Validação Pós-Correção:

- [ ] Usuário consegue fazer login com email/senha
- [ ] auth.uid() retorna ID correto quando logado
- [ ] Usuário consegue ler próprios dados da tabela usuarios
- [ ] Usuário consegue criar/editar próprios dados
- [ ] Não há erros no console do navegador
- [ ] Sessão persiste após refresh da página
- [ ] RLS está funcionando corretamente
- [ ] Trigger de sincronização está ativo
- [ ] Google OAuth funciona (se implementado)

---

## 📋 Resumo Executivo

**Status Atual:** Sistema com múltiplas inconsistências críticas  
**Impacto:** Usuários não conseguem acessar funcionalidades após login  
**Prioridade:** ALTA - Correção imediata necessária  
**Tempo Estimado:** 2-4 horas para implementação completa  

**Próximos Passos:**
1. Executar queries de diagnóstico corrigidas
2. Implementar correções SQL (RLS + triggers)
3. Unificar hooks de autenticação
4. Testar fluxo completo de autenticação
5. Implementar Google OAuth (opcional)

---

*Relatório gerado em: 11/01/2025*  
*Versão do Sistema: Pace Run Hub v1.0*  
*Ambiente: Desenvolvimento/Produção*