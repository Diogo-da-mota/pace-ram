import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useBackgroundHeader, BackgroundHeaderParams, BackgroundHeaderResponse } from '@/hooks/useBackgroundHeader';
import { toast } from 'sonner';

const BackgroundHeaderTest: React.FC = () => {
  const [deviceType, setDeviceType] = useState<'desktop' | 'mobile' | 'tablet'>('desktop');
  const [userId, setUserId] = useState<string>('');
  const [preferPrivate, setPreferPrivate] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<BackgroundHeaderResponse | null>(null);

  const { fetchActiveBackground } = useBackgroundHeader();

  const handleTest = async () => {
    setLoading(true);
    setResult(null);

    try {
      const params: BackgroundHeaderParams = {
        device_type: deviceType,
        user_id: userId || undefined,
        prefer_private: preferPrivate
      };

      const response = await fetchActiveBackground(params);
      setResult(response);

      if (response.status === 'ok') {
        toast.success(response.message);
      } else {
        toast.error(response.message);
      }
    } catch (error) {
      console.error('Erro no teste:', error);
      toast.error('Erro inesperado no teste');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Teste do Sistema de Background Header</CardTitle>
          <CardDescription>
            Teste a funcionalidade de busca de imagens de background ativas conforme especificações
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Parâmetros de entrada */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="device-type">Tipo de Dispositivo *</Label>
              <Select value={deviceType} onValueChange={(value: 'desktop' | 'mobile' | 'tablet') => setDeviceType(value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="desktop">Desktop</SelectItem>
                  <SelectItem value="mobile">Mobile</SelectItem>
                  <SelectItem value="tablet">Tablet</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="user-id">User ID (opcional)</Label>
              <Input
                id="user-id"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="UUID do usuário"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="prefer-private">Prefer Private</Label>
              <div className="flex items-center space-x-2">
                <Switch
                  id="prefer-private"
                  checked={preferPrivate}
                  onCheckedChange={setPreferPrivate}
                />
                <span className="text-sm text-gray-600">
                  {preferPrivate ? 'Gerar Signed URL' : 'URL Pública'}
                </span>
              </div>
            </div>
          </div>

          <Button 
            onClick={handleTest} 
            disabled={loading}
            className="w-full"
          >
            {loading ? 'Testando...' : 'Testar Busca de Background'}
          </Button>
        </CardContent>
      </Card>

      {/* Resultado */}
      {result && (
        <Card>
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 ${result.status === 'ok' ? 'text-green-600' : 'text-red-600'}`}>
              {result.status === 'ok' ? '✅' : '❌'} Resultado
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label>Status:</Label>
                <p className={`font-mono ${result.status === 'ok' ? 'text-green-600' : 'text-red-600'}`}>
                  {result.status}
                </p>
              </div>

              <div>
                <Label>Mensagem:</Label>
                <p className="text-gray-700">{result.message}</p>
              </div>

              {result.data && (
                <div className="space-y-3">
                  <Label>Dados da Imagem:</Label>
                  <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                    <div><strong>ID:</strong> {result.data.id}</div>
                    <div><strong>Tipo Dispositivo:</strong> {result.data.tipo_dispositivo}</div>
                    <div><strong>URL:</strong> 
                      <a 
                        href={result.data.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline ml-2 break-all"
                      >
                        {result.data.url}
                      </a>
                    </div>
                    <div><strong>Posição X:</strong> {result.data.posicao_x}</div>
                    <div><strong>Posição Y:</strong> {result.data.posicao_y}</div>
                    <div><strong>Zoom:</strong> {result.data.zoom}</div>
                    <div><strong>Opacidade:</strong> {result.data.opacidade}</div>
                    <div><strong>Criado Por:</strong> {result.data.criado_por}</div>
                    <div><strong>Criado Em:</strong> {new Date(result.data.criado_em).toLocaleString()}</div>
                  </div>

                  {/* Preview da imagem */}
                  <div className="mt-4">
                    <Label>Preview da Imagem:</Label>
                    <div className="mt-2 border rounded-lg overflow-hidden">
                      <img 
                        src={result.data.url} 
                        alt="Background preview"
                        className="w-full h-48 object-cover"
                        style={{
                          objectPosition: `${result.data.posicao_x}% ${result.data.posicao_y}%`,
                          transform: `scale(${result.data.zoom})`,
                          opacity: result.data.opacidade
                        }}
                        onError={(e) => {
                          console.error('Erro ao carregar imagem:', e);
                          toast.error('Erro ao carregar preview da imagem');
                        }}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* JSON completo */}
              <div>
                <Label>JSON Completo:</Label>
                <pre className="bg-gray-900 text-green-400 p-4 rounded-lg text-sm overflow-auto">
                  {JSON.stringify(result, null, 2)}
                </pre>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default BackgroundHeaderTest;