import { useState, useEffect } from 'react';
import { useBackgroundPublico } from '@/hooks/useBackgroundPublico';

interface BackgroundImageProps {
  className?: string;
}

const BackgroundImage = ({ className = "" }: BackgroundImageProps) => {
  const { backgroundDesktop, backgroundMobile, loading } = useBackgroundPublico();
  const [isMobile, setIsMobile] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  // Detectar se é dispositivo móvel
  useEffect(() => {
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    checkIsMobile();
    window.addEventListener('resize', checkIsMobile);

    return () => window.removeEventListener('resize', checkIsMobile);
  }, []);

  // Selecionar background apropriado
  const currentBackground = isMobile ? backgroundMobile : backgroundDesktop;

  // Se não há background configurado ou ainda está carregando
  if (loading || !currentBackground) {
    return null;
  }

  const handleImageLoad = () => {
    setImageLoaded(true);
  };

  const backgroundStyle = {
    backgroundImage: `url(${currentBackground.url_imagem})`,
    backgroundPosition: `${currentBackground.posicao_x}% ${currentBackground.posicao_y}%`,
    backgroundSize: `${currentBackground.zoom * 100}%`,
    opacity: currentBackground.opacidade,
    backgroundRepeat: 'no-repeat',
    backgroundAttachment: 'fixed',
  };

  return (
    <>
      {/* Preload da imagem para lazy loading */}
      <img
        src={currentBackground.url_imagem}
        alt=""
        style={{ display: 'none' }}
        onLoad={handleImageLoad}
        loading="lazy"
      />
      
      {/* Background div */}
      <div
        className={`fixed inset-0 w-full h-full transition-opacity duration-500 ${
          imageLoaded ? 'opacity-100' : 'opacity-0'
        } ${className}`}
        style={backgroundStyle}
        aria-hidden="true"
      />
    </>
  );
};

export default BackgroundImage;