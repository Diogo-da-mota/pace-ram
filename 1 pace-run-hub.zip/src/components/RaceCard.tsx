import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Image, Calendar } from "lucide-react";

interface RaceCardProps {
  title: string;
  date: string;
  location: string;
  image: string;
  footerText: string;
  link: string;
}

const RaceCard = ({ title, date, location, image, footerText, link }: RaceCardProps) => {
  const handleClick = () => {
    if (link) {
      window.open(link, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <Card className="group overflow-hidden rounded-lg md:rounded-xl bg-card transition-all duration-300 hover:scale-105 border border-border animate-fade-in h-64 md:h-72">
      <div className="h-full flex flex-col">
        {/* Image with badge overlay - SESSÃO 4 implementada */}
        <div className="relative h-36 md:h-44 overflow-hidden">
          <img 
            src={image} 
            alt={title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          {/* Badge com data e local sobre a imagem - 98% da largura */}
          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-[98%] bg-gray-900 bg-opacity-90 text-white px-2 py-2 rounded-full text-sm font-semibold flex items-center gap-2">
            <Calendar className="w-4 h-4 flex-shrink-0" />
            <span className="truncate flex-1">{date} • {location}</span>
          </div>
        </div>
        
        {/* Content */}
        <div className="p-2 md:p-3 flex flex-col flex-1">
          {/* Título na posição original */}
          <h3 className="text-sm md:text-base font-bold text-foreground mb-2 line-clamp-2">
            {title}
          </h3>

          {/* Espaço flexível para empurrar o botão para baixo */}
          <div className="flex-1"></div>

          {/* Botão "Compre as suas fotos" - 98% da largura e cor azul */}
          <div className="mt-auto flex justify-center">
            <Button
              onClick={handleClick}
              className="w-[105%] bg-blue-600 hover:bg-blue-700 text-white rounded-full py-1 md:py-1.5 text-xs md:text-sm transition-colors duration-200"
              disabled={!link}
            >
              <Image className="h-3 w-3 mr-1" />
              COMPRE SUAS FOTOS
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default RaceCard;