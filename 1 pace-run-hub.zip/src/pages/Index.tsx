import Header from "@/components/Header";
import SectionTitle from "@/components/SectionTitle";
import RaceCard from "@/components/RaceCard";
import DiagonalTitle from "@/components/DiagonalTitle";
import RunnerLoader from "@/components/RunnerLoader";
import AnimatedParticles from "@/components/AnimatedParticles";
import CardSection from "@/components/CardSection";
import BackgroundImage from "@/components/BackgroundImage";
import { useCorridasPublicas } from "@/hooks/useCorridasPublicas";
import { useEventosPublicos } from "@/hooks/useEventosPublicos";
import { useRedesSociaisPublicas } from "@/hooks/useRedesSociaisPublicas";
import { useOutrosPublicos } from "@/hooks/useOutrosPublicos";
import { formatDateToBrazilian } from "@/utils/dateFormatter";
import RedeSocialCard from "@/components/RedeSocialCard";
import { useState, useEffect } from "react";

// Import das imagens geradas (para fallback)
import raceExample1 from "@/assets/race-example-1.jpg";
import raceExample2 from "@/assets/race-example-2.jpg";
import raceExample3 from "@/assets/race-example-3.jpg";

const Index = () => {
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const { corridas, loading: loadingCorridas } = useCorridasPublicas();
  const { eventos, loading: loadingEventos } = useEventosPublicos();
  const { redesSociais, loading: loadingRedesSociais } = useRedesSociaisPublicas();
  const { outros, loading: loadingOutros } = useOutrosPublicos();

  // Simular loading inicial da página
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsInitialLoading(false);
    }, 2000); // 2 segundos de loading

    return () => clearTimeout(timer);
  }, []);

  // Mostrar loader se ainda estiver carregando inicialmente
  if (isInitialLoading) {
    return <RunnerLoader message="Preparando sua experiência..." />;
  }

  // Verificar se alguma seção está carregando para mostrar loader único
  const isAnyLoading = loadingRedesSociais || loadingCorridas || loadingEventos || loadingOutros;
  if (isAnyLoading) {
    const loadingMessage = loadingRedesSociais ? "Carregando redes sociais..." :
                          loadingCorridas ? "Carregando corridas..." :
                          loadingEventos ? "Carregando eventos..." :
                          "Carregando conteúdos...";
    return <RunnerLoader message={loadingMessage} />;
  }

  // Fallback images para quando não há imagem definida
  const fallbackImages = [raceExample1, raceExample2, raceExample3];
  
  // Dados de fallback caso não haja corridas no banco
  const corridasFallback = [
    {
      id: "fallback-1",
      titulo: "Maratona Internacional de São Paulo 2024",
      data_evento: "2024-12-15",
      local: "São Paulo, SP",
      imagem_principal: raceExample1,
      texto_rodape: "Compre as suas fotos",
      link_externo: "https://example.com/maratona-sp"
    },
    {
      id: "fallback-2", 
      titulo: "Trail Run Serra da Mantiqueira",
      data_evento: "2025-01-28",
      local: "Campos do Jordão, SP",
      imagem_principal: raceExample2,
      texto_rodape: "Fotos disponíveis em 48h",
      link_externo: "https://example.com/trail-mantiqueira"
    },
    {
      id: "fallback-3",
      titulo: "Corrida Noturna Ibirapuera",
      data_evento: "2025-02-05", 
      local: "São Paulo, SP",
      imagem_principal: raceExample3,
      texto_rodape: "Galeria completa disponível",
      link_externo: "https://example.com/corrida-noturna"
    }
  ];

  // Usar dados reais ou fallback
  const corridasParaExibir = corridas.length > 0 ? corridas : corridasFallback;
  
  // Eventos fallback
  const eventosFallback = [
    {
      id: "event-fallback-1",
      titulo: "Corrida das Pontes 2025 - Recife", 
      link_externo: "https://example.com/corrida-pontes"
    },
    {
      id: "event-fallback-2",
      titulo: "São Silvestre 2024 - São Paulo",
      link_externo: "https://example.com/sao-silvestre"
    },
    {
      id: "event-fallback-3", 
      titulo: "Meia Maratona de Floripa 2025",
      link_externo: "https://example.com/meia-maratona-floripa"
    }
  ];

  const eventosParaExibir = eventos.length > 0 ? eventos : eventosFallback;

  // Redes sociais fallback
  const redesSociaisFallback = [
    {
      id: "social-fallback-1",
      titulo: "Instagram Oficial",
      link: "https://instagram.com/pacerunhub",
      icone: "instagram" as const,
      titulo_secao: "PACE RAM",
      created_at: new Date().toISOString()
    },
    {
      id: "social-fallback-2",
      titulo: "Grupo WhatsApp",
      link: "https://chat.whatsapp.com/example",
      icone: "whatsapp" as const,
      created_at: new Date().toISOString()
    },
    {
      id: "social-fallback-3",
      titulo: "Site Oficial",
      link: "https://pacerunhub.com",
      icone: "link" as const,
      created_at: new Date().toISOString()
    }
  ];

  const redesSociaisParaExibir = redesSociais.length > 0 ? redesSociais : redesSociaisFallback;

  // Outros conteúdos fallback
  const outrosFallback = [
    {
      id: "outros-fallback-1",
      titulo: "Acessar as minhas Fotos",
      link_externo: "https://www.fotop.com.br/fotos/meuspedidos",
      criado_em: new Date().toISOString()
    },
    {
      id: "outros-fallback-2",
      titulo: "Como fazer o download das minhas fotos?",
      link_externo: "https://faq.fotop.com/portal/pt-br/kb/articles/como-fazer-o-download-das-minhas-fotos",
      criado_em: new Date().toISOString()
    }
  ];

  const outrosParaExibir = outros.length > 0 ? outros : outrosFallback;

  return (
    <div className="min-h-screen bg-background relative">
      {/* Background Image */}
      <BackgroundImage className="z-0" />
      
      {/* Conteúdo principal */}
      <div className="relative z-10">
        <Header />

      {/* Seção Redes Sociais */}
      <section className="section-padding bg-background relative pt-24 sm:pt-28 md:pt-20">
        <div className="container-85">
          <div className="animate-fade-in">
            <DiagonalTitle 
              leftText="Redes"
              rightText="Sociais"
              maxWidth="max-w-7xl"
            />
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 lg:gap-6 max-w-4xl mx-auto">
            {redesSociaisParaExibir.map((redeSocial, index) => (
              <div 
                key={redeSocial.id} 
                className="animate-scale-in hover:animate-float"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <RedeSocialCard
                  redeSocial={redeSocial}
                  onEdit={() => {}}
                  onDelete={() => {}}
                  showActions={false}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Seção Corridas */}
      <section id="corridas" className="section-padding bg-black relative overflow-hidden">
        <div className="container-85 relative z-10">
          <div className="animate-slide-up">
            <DiagonalTitle 
              leftText="Corridas"
              rightText="Recentes"
              maxWidth="max-w-7xl"
            />
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-4 lg:gap-6 max-w-7xl mx-auto justify-items-center">
            {corridasParaExibir.map((corrida, index) => (
              <div 
                key={corrida.id}
                className="animate-fade-in hover:scale-105 transition-all duration-300 w-full max-w-[180px] sm:max-w-none"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <RaceCard
                    title={corrida.titulo}
                    date={formatDateToBrazilian(corrida.data_evento)}
                    location={corrida.local}
                    image={corrida.imagem_principal || fallbackImages[index % fallbackImages.length]}
                    
                    link={corrida.link_externo || "#"}
                  />
                </div>
              ))}
            </div>
        </div>
      </section>



      {/* Seção Outros */}
      <section className="section-padding bg-background relative overflow-hidden">
        
        <div className="container-85 relative z-10">
          <div className="animate-slide-up">
            <SectionTitle 
              title="Dúvidas e Links externos"
              showUnderline={true}
            />
          </div>
          
          <CardSection 
            items={outrosParaExibir} 
            animationDelayMultiplier={0.2} 
          />
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white section-padding-sm relative overflow-hidden">

        
        <div className="container-85 text-center relative z-10">
          <div className="animate-fade-in">
            <div className="mb-4">
              
            </div>
            
            <div className="border-t border-white/20 pt-6">
              <p className="text-sm opacity-90">
                © 2025 PACE RAM. Todos os direitos reservados.
              </p>
            </div>
          </div>
        </div>
      </footer>
      </div>
    </div>
  );
};

export default Index;
