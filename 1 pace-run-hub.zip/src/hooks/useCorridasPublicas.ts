import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface CorridaPublica {
  id: string;
  titulo: string;
  data_evento: string;
  local: string;
  imagem_principal?: string;
  link_externo?: string;
  texto_rodape?: string;
  descricao?: string;
}

export const useCorridasPublicas = () => {
  const [corridas, setCorridas] = useState<CorridaPublica[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const buscarCorridasPublicas = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const { data, error } = await supabase
        .from('corridas')
        .select('*')
        .eq('publicado', true)
        .order('data_evento', { ascending: false });

      if (error) throw error;

      setCorridas(data || []);
    } catch (error: any) {
      console.error('Erro ao buscar corridas públicas:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    buscarCorridasPublicas();
  }, []);

  return {
    corridas,
    loading,
    error,
    refetch: buscarCorridasPublicas
  };
};