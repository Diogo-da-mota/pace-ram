import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface BackgroundPublico {
  id: string;
  tipo_dispositivo: 'desktop' | 'mobile';
  url_imagem: string;
  posicao_x: number;
  posicao_y: number;
  zoom: number;
  opacidade: number;
}

export const useBackgroundPublico = () => {
  const [backgroundDesktop, setBackgroundDesktop] = useState<BackgroundPublico | null>(null);
  const [backgroundMobile, setBackgroundMobile] = useState<BackgroundPublico | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchBackgrounds = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('background_configuracoes')
        .select('*')
        .eq('ativo', true)
        .order('atualizado_em', { ascending: false });

      if (fetchError) {
        throw fetchError;
      }

      // Separar backgrounds por tipo de dispositivo
      const desktop = data?.find(bg => bg.tipo_dispositivo === 'desktop') || null;
      const mobile = data?.find(bg => bg.tipo_dispositivo === 'mobile') || null;

      setBackgroundDesktop(desktop);
      setBackgroundMobile(mobile);
    } catch (err) {
      console.error('Erro ao buscar backgrounds:', err);
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBackgrounds();
  }, []);

  return {
    backgroundDesktop,
    backgroundMobile,
    loading,
    error,
    refetch: fetchBackgrounds
  };
};