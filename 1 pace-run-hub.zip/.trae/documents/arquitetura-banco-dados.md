# Arquitetura de Banco de Dados - Pace Run Hub

## 1. Visão Geral do Sistema

O Pace Run Hub é uma plataforma completa para gestão de corridas, fotos de eventos e calendário de competições. O sistema deve suportar múltiplos usuários com diferentes níveis de acesso, permitindo a gestão de eventos esportivos e compartilhamento de conteúdo.

## 2. Entidades Principais Identificadas

Com base na análise do código atual, foram identificadas as seguintes entidades principais:

- **Usuários**: Sistema de autenticação e perfis
- **Corridas**: Eventos esportivos com fotos e informações
- **Calendário**: Eventos futuros e competições
- **Fotos**: Galeria de imagens dos eventos
- **Categorias**: Classificação dos tipos de corrida

## 3. Esquema de Banco de Dados

### 3.1 Diagrama de Relacionamentos

```mermaid
erDiagram
    USUARIOS ||--o{ CORRIDAS : cria
    USUARIOS ||--o{ EVENTOS_CALENDARIO : cria
    CORRIDAS ||--o{ FOTOS_CORRIDA : contem
    CATEGORIAS ||--o{ CORRIDAS : classifica
    USUARIOS ||--o{ FOTOS_CORRIDA : faz_upload
    
    USUARIOS {
        uuid id PK
        varchar email UK
        varchar nome
        varchar senha_hash
        varchar tipo_usuario
        boolean ativo
        timestamp criado_em
        timestamp atualizado_em
    }
    
    CATEGORIAS {
        uuid id PK
        varchar nome UK
        text descricao
        varchar cor_hex
        boolean ativo
        timestamp criado_em
    }
    
    CORRIDAS {
        uuid id PK
        varchar titulo
        date data_evento
        varchar local
        text descricao
        varchar imagem_principal
        varchar link_externo
        varchar texto_rodape
        uuid categoria_id FK
        uuid criado_por FK
        boolean publicado
        timestamp criado_em
        timestamp atualizado_em
    }
    
    EVENTOS_CALENDARIO {
        uuid id PK
        varchar titulo
        date data_evento
        varchar local
        text descricao
        varchar link_externo
        uuid criado_por FK
        boolean publicado
        timestamp criado_em
        timestamp atualizado_em
    }
    
    FOTOS_CORRIDA {
        uuid id PK
        uuid corrida_id FK
        varchar url_foto
        varchar titulo
        text descricao
        varchar numero_peito
        uuid enviado_por FK
        boolean aprovado
        timestamp criado_em
    }
```

### 3.2 Definições das Tabelas (DDL)

#### Tabela: usuarios
```sql
-- Tabela de usuários do sistema
CREATE TABLE usuarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    nome VARCHAR(100) NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    tipo_usuario VARCHAR(20) DEFAULT 'usuario' CHECK (tipo_usuario IN ('admin', 'editor', 'usuario')),
    ativo BOOLEAN DEFAULT true,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para otimização
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_usuarios_tipo ON usuarios(tipo_usuario);
CREATE INDEX idx_usuarios_ativo ON usuarios(ativo);
```

#### Tabela: categorias
```sql
-- Tabela de categorias de corridas
CREATE TABLE categorias (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(100) UNIQUE NOT NULL,
    descricao TEXT,
    cor_hex VARCHAR(7) DEFAULT '#3B82F6',
    ativo BOOLEAN DEFAULT true,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices
CREATE INDEX idx_categorias_nome ON categorias(nome);
CREATE INDEX idx_categorias_ativo ON categorias(ativo);
```

#### Tabela: corridas
```sql
-- Tabela principal de corridas/eventos
CREATE TABLE corridas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    titulo VARCHAR(200) NOT NULL,
    data_evento DATE NOT NULL,
    local VARCHAR(200) NOT NULL,
    descricao TEXT,
    imagem_principal VARCHAR(500),
    link_externo VARCHAR(500),
    texto_rodape VARCHAR(100),
    categoria_id UUID REFERENCES categorias(id),
    criado_por UUID REFERENCES usuarios(id),
    publicado BOOLEAN DEFAULT false,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices
CREATE INDEX idx_corridas_data_evento ON corridas(data_evento DESC);
CREATE INDEX idx_corridas_publicado ON corridas(publicado);
CREATE INDEX idx_corridas_categoria ON corridas(categoria_id);
CREATE INDEX idx_corridas_criado_por ON corridas(criado_por);
```

#### Tabela: eventos_calendario
```sql
-- Tabela de eventos do calendário
CREATE TABLE eventos_calendario (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    titulo VARCHAR(200) NOT NULL,
    data_evento DATE NOT NULL,
    local VARCHAR(200),
    descricao TEXT,
    link_externo VARCHAR(500),
    criado_por UUID REFERENCES usuarios(id),
    publicado BOOLEAN DEFAULT false,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices
CREATE INDEX idx_eventos_data ON eventos_calendario(data_evento ASC);
CREATE INDEX idx_eventos_publicado ON eventos_calendario(publicado);
CREATE INDEX idx_eventos_criado_por ON eventos_calendario(criado_por);
```

#### Tabela: fotos_corrida
```sql
-- Tabela de fotos das corridas
CREATE TABLE fotos_corrida (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    corrida_id UUID REFERENCES corridas(id) ON DELETE CASCADE,
    url_foto VARCHAR(500) NOT NULL,
    titulo VARCHAR(200),
    descricao TEXT,
    numero_peito VARCHAR(20),
    enviado_por UUID REFERENCES usuarios(id),
    aprovado BOOLEAN DEFAULT false,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices
CREATE INDEX idx_fotos_corrida_id ON fotos_corrida(corrida_id);
CREATE INDEX idx_fotos_aprovado ON fotos_corrida(aprovado);
CREATE INDEX idx_fotos_numero_peito ON fotos_corrida(numero_peito);
CREATE INDEX idx_fotos_enviado_por ON fotos_corrida(enviado_por);
```

### 3.3 Dados Iniciais

#### Categorias padrão
```sql
INSERT INTO categorias (nome, descricao, cor_hex) VALUES
('Maratona', 'Corridas de 42,195 km', '#E11D48'),
('Meia Maratona', 'Corridas de 21,097 km', '#3B82F6'),
('10K', 'Corridas de 10 quilômetros', '#10B981'),
('5K', 'Corridas de 5 quilômetros', '#F59E0B'),
('Trail Run', 'Corridas em trilhas e montanhas', '#8B5CF6'),
('Corrida Rústica', 'Corridas em terrenos variados', '#EF4444'),
('Corrida Noturna', 'Corridas realizadas à noite', '#6366F1');
```

#### Usuário administrador padrão
```sql
INSERT INTO usuarios (email, nome, senha_hash, tipo_usuario) VALUES
('paceram@gmail.com', 'Administrador PACE RAM', '$2b$10$exemplo_hash_senha', 'admin');
```

## 4. Configurações de Segurança (Supabase)

### 4.1 Row Level Security (RLS)

```sql
-- Habilitar RLS em todas as tabelas
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE categorias ENABLE ROW LEVEL SECURITY;
ALTER TABLE corridas ENABLE ROW LEVEL SECURITY;
ALTER TABLE eventos_calendario ENABLE ROW LEVEL SECURITY;
ALTER TABLE fotos_corrida ENABLE ROW LEVEL SECURITY;
```

### 4.2 Políticas de Acesso

```sql
-- Políticas para tabela usuarios
CREATE POLICY "Usuários podem ver próprio perfil" ON usuarios
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Admins podem ver todos usuários" ON usuarios
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() AND tipo_usuario = 'admin'
        )
    );

-- Políticas para tabela corridas
CREATE POLICY "Todos podem ver corridas publicadas" ON corridas
    FOR SELECT USING (publicado = true);

CREATE POLICY "Editores podem gerenciar corridas" ON corridas
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() AND tipo_usuario IN ('admin', 'editor')
        )
    );

-- Políticas para tabela eventos_calendario
CREATE POLICY "Todos podem ver eventos publicados" ON eventos_calendario
    FOR SELECT USING (publicado = true);

CREATE POLICY "Editores podem gerenciar eventos" ON eventos_calendario
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() AND tipo_usuario IN ('admin', 'editor')
        )
    );

-- Políticas para tabela fotos_corrida
CREATE POLICY "Todos podem ver fotos aprovadas" ON fotos_corrida
    FOR SELECT USING (aprovado = true);

CREATE POLICY "Usuários podem enviar fotos" ON fotos_corrida
    FOR INSERT WITH CHECK (auth.uid() = enviado_por);

CREATE POLICY "Editores podem gerenciar fotos" ON fotos_corrida
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() AND tipo_usuario IN ('admin', 'editor')
        )
    );
```

### 4.3 Permissões para Roles

```sql
-- Permissões para role anon (usuários não autenticados)
GRANT SELECT ON categorias TO anon;
GRANT SELECT ON corridas TO anon;
GRANT SELECT ON eventos_calendario TO anon;
GRANT SELECT ON fotos_corrida TO anon;

-- Permissões para role authenticated (usuários autenticados)
GRANT ALL PRIVILEGES ON usuarios TO authenticated;
GRANT ALL PRIVILEGES ON categorias TO authenticated;
GRANT ALL PRIVILEGES ON corridas TO authenticated;
GRANT ALL PRIVILEGES ON eventos_calendario TO authenticated;
GRANT ALL PRIVILEGES ON fotos_corrida TO authenticated;
```

## 5. Considerações de Performance

### 5.1 Índices Estratégicos
- Índices compostos para consultas frequentes
- Índices em campos de filtro (data, status, categoria)
- Índices em chaves estrangeiras para joins eficientes

### 5.2 Otimizações
- Uso de UUIDs para escalabilidade
- Timestamps com timezone para consistência global
- Campos de status para soft deletes
- Paginação em consultas de listagem

## 6. Escalabilidade

### 6.1 Estratégias de Crescimento
- Particionamento por data nas tabelas de eventos
- Arquivamento de dados antigos
- Cache de consultas frequentes
- CDN para armazenamento de imagens

### 6.2 Monitoramento
- Logs de performance de queries
- Métricas de uso por tabela
- Alertas de crescimento de dados

## 7. Backup e Recuperação

### 7.1 Estratégia de Backup
- Backup automático diário (Supabase)
- Backup incremental de imagens
- Versionamento de esquema

### 7.2 Plano de Recuperação
- Procedimentos de restore
- Testes de recuperação mensais
- Documentação de rollback

Este esquema de banco de dados fornece uma base sólida para o Pace Run Hub, suportando múltiplos usuários, diferentes tipos de conteúdo e crescimento futuro da plataforma.