# 🚀 PROMPT UNIVERSAL - SITES COM PERFORMANCE OTIMIZADA

## 📋 INSTRUÇÕES PARA O DESENVOLVEDOR

Use este prompt para criar qualquer site/aplicação web já com **performance otimizada desde o início**. Baseado nas melhores práticas implementadas e testadas.

---

## 🎯 PROMPT UNIVERSAL

```
Crie um site/aplicação web [DESCREVER O PROJETO] seguindo OBRIGATORIAMENTE estas especificações de performance:

## 🏗️ ARQUITETURA OBRIGATÓRIA

### Frontend Stack:
- React 18+ com TypeScript
- Vite (build tool)
- TailwindCSS (styling)
- React Query/TanStack Query (state management)
- React Router DOM (routing)

### Backend/Database:
- Supabase (BaaS completo)
- PostgreSQL (via Supabase)
- Realtime subscriptions (Supabase)
- Authentication (Supabase Auth)

## ⚡ PERFORMANCE REQUIREMENTS (OBRIGATÓRIO)

### 1. ZERO LOADING ARTIFICIAL
❌ PROIBIDO: setTimeout, delays artificiais, spinners desnecessários
✅ OBRIGATÓRIO: Loading real apenas quando necessário

### 2. CONSOLE LIMPO
❌ PROIBIDO: console.log em produção
✅ PERMITIDO: console.error para debugging crítico
✅ OBRIGATÓRIO: Logs estruturados apenas para Realtime essencial

### 3. MEMORY LEAK PREVENTION
✅ OBRIGATÓRIO: Cleanup em TODOS os useEffect
```typescript
useEffect(() => {
  // Sua lógica aqui
  
  return () => {
    // CLEANUP OBRIGATÓRIO
    // Remover event listeners
    // Cancelar subscriptions
    // Limpar timers/intervals
  };
}, []);
```

### 4. REALTIME OTIMIZADO
✅ OBRIGATÓRIO: Supabase Realtime para dados dinâmicos
✅ OBRIGATÓRIO: Subscriptions com cleanup adequado
```typescript
const channel = supabase
  .channel('table-changes')
  .on('postgres_changes', { event: '*', schema: 'public', table: 'tabela' }, 
      (payload) => refetchData())
  .subscribe();

return () => supabase.removeChannel(channel);
```

### 5. CACHE INTELIGENTE
✅ OBRIGATÓRIO: Cache localStorage com TTL (5-15min)
✅ OBRIGATÓRIO: React.memo para componentes pesados
✅ OBRIGATÓRIO: useMemo para cálculos complexos
```typescript
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutos
const getCachedData = () => {
  const cached = localStorage.getItem(CACHE_KEY);
  if (cached) {
    const data = JSON.parse(cached);
    if (Date.now() - data.timestamp < CACHE_DURATION) {
      return data.value;
    }
  }
  return null;
};
```

### 6. MOBILE PERFORMANCE
✅ OBRIGATÓRIO: backgroundAttachment: 'scroll' em mobile
✅ OBRIGATÓRIO: Responsive design otimizado
✅ OBRIGATÓRIO: Touch interactions suaves
```typescript
const isMobile = window.innerWidth <= 768;
const backgroundStyle = {
  backgroundAttachment: isMobile ? 'scroll' : 'fixed'
};
```

### 7. COMPONENT OPTIMIZATION
✅ OBRIGATÓRIO: React.memo para componentes que re-renderizam
✅ OBRIGATÓRIO: useCallback para funções passadas como props
✅ OBRIGATÓRIO: useMemo para objetos/arrays complexos

### 8. ERROR HANDLING
✅ OBRIGATÓRIO: Try/catch em todas as operações async
✅ OBRIGATÓRIO: Error boundaries para componentes
✅ OBRIGATÓRIO: Fallbacks graceful para falhas

## 📁 ESTRUTURA DE ARQUIVOS OBRIGATÓRIA

```
src/
├── components/
│   ├── ui/              # Componentes base (shadcn/ui)
│   ├── [Feature]Card.tsx # Componentes específicos
│   └── Layout.tsx       # Layout principal
├── hooks/
│   ├── use[Feature].ts  # Hooks customizados
│   ├── use[Feature]Public.ts # Hooks para dados públicos
│   └── useAuth.ts       # Autenticação
├── pages/
│   ├── Index.tsx        # Página inicial
│   ├── Dashboard.tsx    # Admin/Dashboard
│   └── [Feature].tsx    # Páginas específicas
├── utils/
│   ├── cache.ts         # Utilitários de cache
│   ├── cleanup.ts       # Utilitários de cleanup
│   └── performance.ts   # Utilitários de performance
└── integrations/
    └── supabase/        # Configuração Supabase
```

## 🔧 HOOKS PATTERN OBRIGATÓRIO

### Hook Público (para dados públicos):
```typescript
export const use[Feature]Public = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const fetchData = async () => {
    // Verificar cache primeiro
    const cached = getCachedData();
    if (cached) {
      setData(cached);
      setLoading(false);
      return;
    }
    
    // Buscar dados
    const { data: result } = await supabase.from('table').select('*');
    setData(result || []);
    setCachedData(result);
    setLoading(false);
  };
  
  useEffect(() => {
    fetchData();
    
    // Realtime subscription
    const channel = supabase
      .channel('table-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'table' }, 
          () => fetchData())
      .subscribe();
    
    return () => supabase.removeChannel(channel);
  }, []);
  
  return { data, loading, refetch: fetchData };
};
```

## 🎨 UI/UX REQUIREMENTS

### Design System:
✅ OBRIGATÓRIO: Design consistente com Tailwind
✅ OBRIGATÓRIO: Dark mode support
✅ OBRIGATÓRIO: Responsive design (mobile-first)
✅ OBRIGATÓRIO: Animações suaves (CSS transitions)
✅ OBRIGATÓRIO: Loading states apropriados

### Acessibilidade:
✅ OBRIGATÓRIO: Semantic HTML
✅ OBRIGATÓRIO: ARIA labels
✅ OBRIGATÓRIO: Keyboard navigation
✅ OBRIGATÓRIO: Color contrast adequado

## 🗄️ DATABASE DESIGN

### Supabase Tables Pattern:
```sql
-- Exemplo de tabela otimizada
CREATE TABLE items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo VARCHAR(255) NOT NULL,
  descricao TEXT,
  ativo BOOLEAN DEFAULT true,
  visivel_publico BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX idx_items_ativo ON items(ativo);
CREATE INDEX idx_items_visivel ON items(visivel_publico);
CREATE INDEX idx_items_created ON items(created_at DESC);

-- RLS (Row Level Security)
ALTER TABLE items ENABLE ROW LEVEL SECURITY;

-- Políticas básicas
CREATE POLICY "Leitura pública" ON items FOR SELECT TO anon, authenticated 
  USING (ativo = true AND visivel_publico = true);

CREATE POLICY "Admin completo" ON items FOR ALL TO authenticated 
  USING (auth.role() = 'authenticated');
```

## 🚀 DEPLOYMENT CHECKLIST

### Antes do Deploy:
- [ ] Remover todos console.log
- [ ] Verificar cleanup de useEffect
- [ ] Testar cache funcionando
- [ ] Testar Realtime funcionando
- [ ] Verificar mobile performance
- [ ] Testar error handling
- [ ] Verificar acessibilidade
- [ ] Otimizar imagens
- [ ] Configurar .env corretamente

### Performance Targets:
- [ ] First Contentful Paint < 1.5s
- [ ] Largest Contentful Paint < 2.5s
- [ ] Cumulative Layout Shift < 0.1
- [ ] First Input Delay < 100ms
- [ ] Console limpo (0 logs desnecessários)
- [ ] Memory leaks = 0

## 🔍 TESTING CHECKLIST

### Performance Tests:
- [ ] Lighthouse Score > 90
- [ ] Network tab: requisições otimizadas
- [ ] Console tab: sem logs desnecessários
- [ ] Memory tab: sem vazamentos
- [ ] Mobile performance adequada

### Functional Tests:
- [ ] Realtime funcionando
- [ ] Cache funcionando
- [ ] Error handling funcionando
- [ ] Responsive design
- [ ] Acessibilidade

## 📝 EXEMPLO DE IMPLEMENTAÇÃO

### Componente Otimizado:
```typescript
import React, { memo, useMemo } from 'react';

interface OptimizedComponentProps {
  data: any[];
  onAction: (id: string) => void;
}

const OptimizedComponent = memo(({ data, onAction }: OptimizedComponentProps) => {
  const processedData = useMemo(() => {
    return data.filter(item => item.active).sort((a, b) => 
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }, [data]);

  return (
    <div className="grid gap-4">
      {processedData.map((item) => (
        <div key={item.id} className="p-4 border rounded">
          <h3>{item.title}</h3>
          <button onClick={() => onAction(item.id)}>
            Ação
          </button>
        </div>
      ))}
    </div>
  );
});

OptimizedComponent.displayName = 'OptimizedComponent';
export default OptimizedComponent;
```

## ⚠️ REGRAS CRÍTICAS

### NUNCA FAÇA:
❌ Loading artificial com setTimeout
❌ console.log em produção
❌ useEffect sem cleanup
❌ Subscriptions sem removeChannel
❌ Event listeners sem removeEventListener
❌ backgroundAttachment: fixed em mobile
❌ Re-renders desnecessários
❌ Fetch sem cache
❌ Componentes sem memo quando necessário

### SEMPRE FAÇA:
✅ Cache com TTL
✅ Cleanup adequado
✅ Error handling
✅ Realtime otimizado
✅ Mobile performance
✅ Console limpo
✅ Memory leak prevention
✅ Component optimization

## 🎯 RESULTADO ESPERADO

Ao seguir este prompt, você terá:
- ⚡ Site 100% mais rápido (sem loading artificial)
- 🧹 Console 90% mais limpo
- 🔄 Realtime funcionando perfeitamente
- 🛡️ Zero memory leaks
- 📱 Performance mobile otimizada
- 💾 Cache inteligente implementado
- 🚀 Pronto para produção desde o dia 1

---

## 📞 SUPORTE

Este prompt foi baseado nas otimizações reais implementadas no PACE RUN HUB, testadas e aprovadas em produção.

**Use este prompt como base para QUALQUER projeto web e tenha performance garantida desde o início!**
```

---

## 🔧 COMO USAR ESTE PROMPT

1. **Copie o prompt completo** acima
2. **Substitua [DESCREVER O PROJETO]** pela descrição do seu site
3. **Cole no seu AI assistant** favorito
4. **Siga todas as especificações** obrigatórias
5. **Teste a performance** antes do deploy

## 🎯 GARANTIA DE RESULTADO

Este prompt garante que seu site terá:
- **Performance otimizada** desde o primeiro dia
- **Zero problemas** de memory leak
- **Console limpo** para debugging
- **Realtime funcionando** perfeitamente
- **Mobile otimizado** para todos dispositivos

**Use e tenha sucesso garantido! 🚀**