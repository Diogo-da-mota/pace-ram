# Sistema Dark Mode - Implementação Técnica

## 1. Visão Geral do Projeto

O sistema de dark mode do PACE RUN HUB permite alternância entre modo claro e escuro com áreas específicas que permanecem sempre escuras, mantendo a identidade visual do projeto.

## 2. Especificações de Comportamento

### 2.1 Áreas Fixas (Sempre Escuras)
- **Header**: Permanece sempre com `bg-black/95` (já implementado)
- **Footer**: Permanece sempre com `bg-black` 
- **Seção "Corridas Recentes"**: Permanece sempre com `bg-black`

### 2.2 Áreas com Alternância Dark/Light
- **Rota principal (/)**: Todas as seções exceto "Corridas Recentes"
- **Rota /calendario**: Todas as seções

## 3. Estado Atual da Implementação

### 3.1 Componentes Já Implementados
✅ Hook `useDarkMode` funcional  
✅ Persistência no localStorage  
✅ Botão toggle no Header  
✅ Variáveis CSS configuradas no Tailwind  
✅ Transições suaves configuradas  

### 3.2 Configuração Técnica Existente

**Hook useDarkMode.ts:**
```typescript
- Detecta preferência do sistema
- Persiste no localStorage
- Aplica classe 'dark' no documentElement
- Função toggleDarkMode() disponível
```

**Variáveis CSS (index.css):**
```css
:root {
  --background: 0 0% 100%;
  --foreground: 0 0% 0%;
  /* ... outras variáveis */
}

.dark {
  --background: 0 0% 3.9%;
  --foreground: 0 0% 98%;
  /* ... outras variáveis */
}
```

## 4. Melhorias Necessárias

### 4.1 Rota Principal (/) - Ajustes Requeridos

**Seção Redes Sociais:**
```typescript
// ATUAL:
<section className="section-padding bg-background relative pt-24 sm:pt-28 md:pt-20">

// MANTER (já correto)
```

**Seção Corridas Recentes:**
```typescript
// ATUAL:
<section className="section-padding bg-black relative overflow-hidden">

// MANTER (sempre escura conforme requisito)
```

**Seção Outros:**
```typescript
// ATUAL:
<section className="section-padding bg-background relative overflow-hidden">

// MANTER (já correto)
```

**Footer:**
```typescript
// ATUAL:
<footer className="bg-black text-white section-padding-sm relative overflow-hidden">

// MANTER (sempre escuro conforme requisito)
```

### 4.2 Rota /calendario - Ajustes Requeridos

**Verificar componentes:**
- GradientSection
- Filtros (Select components)
- EventoCard
- Seção de eventos com `bg-black`

### 4.3 Componentes que Precisam de Verificação

**Cards e Componentes UI:**
- RedeSocialCard
- RaceCard  
- EventoCard
- OutroCard
- Select components
- Button components

## 5. Plano de Implementação

### 5.1 Fase 1: Auditoria de Componentes
1. Verificar todos os componentes de card
2. Identificar classes que precisam de variantes dark
3. Testar contraste em ambos os modos

### 5.2 Fase 2: Ajustes na Rota /calendario
1. Verificar seção de eventos (atualmente `bg-black`)
2. Ajustar para `bg-background dark:bg-background`
3. Manter contraste adequado

### 5.3 Fase 3: Refinamentos
1. Verificar todos os componentes Select
2. Ajustar cores de borda e hover states
3. Testar responsividade em ambos os modos

## 6. Classes Tailwind Recomendadas

### 6.1 Backgrounds
```css
/* Para seções que alternam */
bg-background dark:bg-background

/* Para seções sempre escuras */
bg-black (manter como está)

/* Para cards */
bg-card dark:bg-card
```

### 6.2 Textos
```css
/* Texto principal */
text-foreground dark:text-foreground

/* Texto secundário */
text-muted-foreground dark:text-muted-foreground
```

### 6.3 Bordas
```css
/* Bordas padrão */
border-border dark:border-border

/* Bordas de input */
border-input dark:border-input
```

## 7. Testes de Validação

### 7.1 Checklist de Funcionalidade
- [ ] Toggle funciona em todas as páginas
- [ ] Persistência mantida entre sessões
- [ ] Header sempre escuro
- [ ] Footer sempre escuro  
- [ ] Seção Corridas Recentes sempre escura
- [ ] Outras seções alternam corretamente
- [ ] Contraste adequado em ambos os modos
- [ ] Transições suaves funcionando

### 7.2 Checklist de Componentes
- [ ] RedeSocialCard
- [ ] RaceCard
- [ ] EventoCard  
- [ ] OutroCard
- [ ] Select components
- [ ] Button states
- [ ] Input fields
- [ ] Modal components

## 8. Considerações de Acessibilidade

### 8.1 Contraste
- Manter ratio mínimo de 4.5:1 para texto normal
- Manter ratio mínimo de 3:1 para texto grande
- Verificar contraste em estados hover/focus

### 8.2 Indicadores Visuais
- Botão toggle deve indicar claramente o estado atual
- Ícones Sol/Lua para identificação visual
- Estados de foco visíveis em ambos os modos

## 9. Estrutura de Arquivos Afetados

```
src/
├── hooks/
│   └── useDarkMode.ts ✅ (já implementado)
├── components/
│   ├── Header.tsx ✅ (já implementado)
│   ├── RedeSocialCard.tsx (verificar)
│   ├── RaceCard.tsx (verificar)
│   ├── EventoCard.tsx (verificar)
│   └── ui/ (verificar componentes)
├── pages/
│   ├── Index.tsx (ajustar se necessário)
│   └── Calendario.tsx (verificar seção eventos)
└── index.css ✅ (já configurado)
```

## 10. Próximos Passos

1. **Auditoria Completa**: Verificar todos os componentes
2. **Ajustes Pontuais**: Corrigir componentes que não suportam dark mode
3. **Testes Visuais**: Validar em ambos os modos
4. **Documentação**: Atualizar guia de componentes
5. **Deploy**: Testar em produção

---

**Status**: Documentação técnica criada  
**Próxima Ação**: Iniciar auditoria de componentes  
**Responsável**: Equipe de desenvolvimento