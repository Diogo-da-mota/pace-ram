# Documento de Arquitetura Técnica - Pace Run Hub

## 1. Arquitetura do Sistema

```mermaid
graph TD
    A[Navegador do Usuário] --> B[React Frontend Application]
    B --> C[Supabase SDK]
    C --> D[Supabase Service]

    subgraph "Camada Frontend"
        B
    end

    subgraph "Camada de Serviços (Fornecida pelo Supabase)"
        D
        E[PostgreSQL Database]
        F[Authentication Service]
        G[Storage Service]
        H[Real-time Subscriptions]
    end

    D --> E
    D --> F
    D --> G
    D --> H
```

## 2. Descrição das Tecnologias

* **Frontend**: React\@18 + TypeScript + TailwindCSS\@3 + Vite

* **Backend**: Supabase (Backend-as-a-Service)

* **Banco de Dados**: PostgreSQL (fornecido pelo Supabase)

* **Autenticação**: Supabase Auth

* **Armazenamento**: Supabase Storage

* **Hospedagem**: Vercel (frontend) + Supabase (backend)

## 3. Definições de Rotas

| Rota                | Propósito                                                                 |
| ------------------- | ------------------------------------------------------------------------- |
| /                   | Página inicial com hero section, corridas recentes e prévia do calendário |
| /login              | Página de autenticação para usuários e administradores                    |
| /dashboard          | Painel administrativo para gestão de corridas e eventos                   |
| /corrida/:id        | Página detalhada de uma corrida específica com galeria de fotos           |
| /calendario         | Calendário completo de eventos futuros                                    |
| /galeria/:corridaId | Galeria de fotos de uma corrida específica                                |

## 4. Definições de API

### 4.1 APIs Principais do Supabase

#### Autenticação de Usuários

```typescript
// Login
const { data, error } = await supabase.auth.signInWithPassword({
  email: 'usuario@email.com',
  password: 'senha123'
})

// Registro
const { data, error } = await supabase.auth.signUp({
  email: 'usuario@email.com',
  password: 'senha123',
  options: {
    data: {
      nome: 'Nome do Usuário'
    }
  }
})
```

#### Gestão de Corridas

```typescript
// Buscar corridas publicadas
const { data, error } = await supabase
  .from('corridas')
  .select(`
    *,
    categorias(nome, cor_hex),
    usuarios(nome)
  `)
  .eq('publicado', true)
  .order('data_evento', { ascending: false })

// Criar nova corrida
const { data, error } = await supabase
  .from('corridas')
  .insert({
    titulo: 'Maratona de São Paulo 2024',
    data_evento: '2024-12-15',
    local: 'São Paulo, SP',
    categoria_id: 'uuid-categoria',
    criado_por: 'uuid-usuario'
  })
```

#### Gestão de Fotos

```typescript
// Upload de foto
const { data, error } = await supabase.storage
  .from('fotos-corridas')
  .upload(`corrida-${corridaId}/${nomeArquivo}`, arquivo)

// Buscar fotos de uma corrida
const { data, error } = await supabase
  .from('fotos_corrida')
  .select('*')
  .eq('corrida_id', corridaId)
  .eq('aprovado', true)
```

### 4.2 Tipos TypeScript Compartilhados

```typescript
// Tipos de dados principais
export interface Usuario {
  id: string;
  email: string;
  nome: string;
  tipo_usuario: 'admin' | 'editor' | 'usuario';
  ativo: boolean;
  criado_em: string;
  atualizado_em: string;
}

export interface Categoria {
  id: string;
  nome: string;
  descricao?: string;
  cor_hex: string;
  ativo: boolean;
  criado_em: string;
}

export interface Corrida {
  id: string;
  titulo: string;
  data_evento: string;
  local: string;
  descricao?: string;
  imagem_principal?: string;
  link_externo?: string;
  texto_rodape?: string;
  categoria_id?: string;
  criado_por: string;
  publicado: boolean;
  criado_em: string;
  atualizado_em: string;
  // Relacionamentos
  categorias?: Categoria;
  usuarios?: Pick<Usuario, 'nome'>;
}

export interface EventoCalendario {
  id: string;
  titulo: string;
  data_evento: string;
  local?: string;
  descricao?: string;
  link_externo?: string;
  criado_por: string;
  publicado: boolean;
  criado_em: string;
  atualizado_em: string;
}

export interface FotoCorrida {
  id: string;
  corrida_id: string;
  url_foto: string;
  titulo?: string;
  descricao?: string;
  numero_peito?: string;
  enviado_por: string;
  aprovado: boolean;
  criado_em: string;
}
```

## 5. Arquitetura do Frontend

```mermaid
graph TD
    A[App.tsx] --> B[Router]
    B --> C[Páginas]
    B --> D[Componentes]
    B --> E[Hooks]
    B --> F[Lib/Utils]
    
    subgraph "Páginas"
        C1[Index.tsx]
        C2[Login.tsx]
        C3[Dashboard.tsx]
        C4[Corrida.tsx]
        C5[Calendario.tsx]
    end
    
    subgraph "Componentes"
        D1[Header.tsx]
        D2[RaceCard.tsx]
        D3[SectionTitle.tsx]
        D4[UI Components]
    end
    
    subgraph "Hooks Customizados"
        E1[useAuth.ts]
        E2[useCorridas.ts]
        E3[useCalendario.ts]
    end
    
    subgraph "Bibliotecas"
        F1[supabase.ts]
        F2[utils.ts]
        F3[types.ts]
    end
    
    C --> C1
    C --> C2
    C --> C3
    C --> C4
    C --> C5
    
    D --> D1
    D --> D2
    D --> D3
    D --> D4
    
    E --> E1
    E --> E2
    E --> E3
    
    F --> F1
    F --> F2
    F --> F3
```

## 6. Modelo de Dados

### 6.1 Diagrama de Entidades

```mermaid
erDiagram
    USUARIOS ||--o{ CORRIDAS : cria
    USUARIOS ||--o{ EVENTOS_CALENDARIO : cria
    CORRIDAS ||--o{ FOTOS_CORRIDA : contem
    CATEGORIAS ||--o{ CORRIDAS : classifica
    USUARIOS ||--o{ FOTOS_CORRIDA : envia
    
    USUARIOS {
        uuid id PK
        varchar email UK
        varchar nome
        varchar senha_hash
        varchar tipo_usuario
        boolean ativo
        timestamp criado_em
        timestamp atualizado_em
    }
    
    CATEGORIAS {
        uuid id PK
        varchar nome UK
        text descricao
        varchar cor_hex
        boolean ativo
        timestamp criado_em
    }
    
    CORRIDAS {
        uuid id PK
        varchar titulo
        date data_evento
        varchar local
        text descricao
        varchar imagem_principal
        varchar link_externo
        varchar texto_rodape
        uuid categoria_id FK
        uuid criado_por FK
        boolean publicado
        timestamp criado_em
        timestamp atualizado_em
    }
    
    EVENTOS_CALENDARIO {
        uuid id PK
        varchar titulo
        date data_evento
        varchar local
        text descricao
        varchar link_externo
        uuid criado_por FK
        boolean publicado
        timestamp criado_em
        timestamp atualizado_em
    }
    
    FOTOS_CORRIDA {
        uuid id PK
        uuid corrida_id FK
        varchar url_foto
        varchar titulo
        text descricao
        varchar numero_peito
        uuid enviado_por FK
        boolean aprovado
        timestamp criado_em
    }
```

### 6.2 Scripts de Criação das Tabelas

```sql
-- Tabela de usuários
CREATE TABLE usuarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    nome VARCHAR(100) NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    tipo_usuario VARCHAR(20) DEFAULT 'usuario' CHECK (tipo_usuario IN ('admin', 'editor', 'usuario')),
    ativo BOOLEAN DEFAULT true,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de categorias
CREATE TABLE categorias (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(100) UNIQUE NOT NULL,
    descricao TEXT,
    cor_hex VARCHAR(7) DEFAULT '#3B82F6',
    ativo BOOLEAN DEFAULT true,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de corridas
CREATE TABLE corridas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    titulo VARCHAR(200) NOT NULL,
    data_evento DATE NOT NULL,
    local VARCHAR(200) NOT NULL,
    descricao TEXT,
    imagem_principal VARCHAR(500),
    link_externo VARCHAR(500),
    texto_rodape VARCHAR(100),
    categoria_id UUID REFERENCES categorias(id),
    criado_por UUID REFERENCES usuarios(id),
    publicado BOOLEAN DEFAULT false,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de eventos do calendário
CREATE TABLE eventos_calendario (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    titulo VARCHAR(200) NOT NULL,
    data_evento DATE NOT NULL,
    local VARCHAR(200),
    descricao TEXT,
    link_externo VARCHAR(500),
    criado_por UUID REFERENCES usuarios(id),
    publicado BOOLEAN DEFAULT false,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de fotos das corridas
CREATE TABLE fotos_corrida (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    corrida_id UUID REFERENCES corridas(id) ON DELETE CASCADE,
    url_foto VARCHAR(500) NOT NULL,
    titulo VARCHAR(200),
    descricao TEXT,
    numero_peito VARCHAR(20),
    enviado_por UUID REFERENCES usuarios(id),
    aprovado BOOLEAN DEFAULT false,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para otimização
CREATE INDEX idx_corridas_data_evento ON corridas(data_evento DESC);
CREATE INDEX idx_corridas_publicado ON corridas(publicado);
CREATE INDEX idx_eventos_data ON eventos_calendario(data_evento ASC);
CREATE INDEX idx_fotos_corrida_id ON fotos_corrida(corrida_id);
CREATE INDEX idx_fotos_numero_peito ON fotos_corrida(numero_peito);

-- Configurações de segurança (RLS)
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE categorias ENABLE ROW LEVEL SECURITY;
ALTER TABLE corridas ENABLE ROW LEVEL SECURITY;
ALTER TABLE eventos_calendario ENABLE ROW LEVEL SECURITY;
ALTER TABLE fotos_corrida ENABLE ROW LEVEL SECURITY;

-- Permissões básicas
GRANT SELECT ON categorias TO anon;
GRANT SELECT ON corridas TO anon;
GRANT SELECT ON eventos_calendario TO anon;
GRANT SELECT ON fotos_corrida TO anon;

GRANT ALL PRIVILEGES ON usuarios TO authenticated;
GRANT ALL PRIVILEGES ON categorias TO authenticated;
GRANT ALL PRIVILEGES ON corridas TO authenticated;
GRANT ALL PRIVILEGES ON eventos_calendario TO authenticated;
GRANT ALL PRIVILEGES ON fotos_corrida TO authenticated;

-- Dados iniciais
INSERT INTO categorias (nome, descricao, cor_hex) VALUES
('Maratona', 'Corridas de 42,195 km', '#E11D48'),
('Meia Maratona', 'Corridas de 21,097 km', '#3B82F6'),
('10K', 'Corridas de 10 quilômetros', '#10B981'),
('5K', 'Corridas de 5 quilômetros', '#F59E0B'),
('Trail Run', 'Corridas em trilhas e montanhas', '#8B5CF6'),
('Corrida Rústica', 'Corridas em terrenos variados', '#EF4444'),
('Corrida Noturna', 'Corridas realizadas à noite', '#6366F1');
```

## 7. Configuração de Segurança

### 7.1 Autenticação

* JWT tokens gerenciados pelo Supabase

* Sessões persistentes com refresh automático

* Logout seguro com invalidação de tokens

### 7.2 Autorização

* Row Level Security (RLS) no PostgreSQL

* Políticas granulares por tipo de usuário

* Validação de permissões no frontend e backend

### 7.3 Proteção de Dados

* Criptografia de senhas com bcrypt

* Comunicação HTTPS obrigatória

* Sanitização de inputs do usuário

* Validação de tipos TypeScript

## 8. Performance e Escalabilidade

### 8.1 Otimizações Frontend

* Code splitting com React.lazy

* Lazy loading de imagens

* Cache de consultas com React Query

* Compressão de assets com Vite

### 8.2 Otimizações Backend

* Índices estratégicos no banco de dados

* Paginação em consultas grandes

* CDN para entrega de imagens

* Cache de consultas frequentes

### 8.3 Monitoramento

* Logs de performance no Supabase

* Métricas de uso da aplicação

* Alertas de erro e disponibilidade

* Analytics de comportamento do usuário

Esta arquitetura técnica fornece uma base sólida e escalável para o Pace Run Hub, aproveitando as melhores práticas de desenvolvimento moderno e a robustez do ecossistema Supabase.
